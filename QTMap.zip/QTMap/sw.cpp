#include "sw.h"
#include "ui_sw.h"
#include "mw1.h"

SW::SW(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::SW),
    _backGround(":/pics/bk.jpg"),
    _startButton(":/pics/start.png"),
    _quitButton(":/pics/quit.png")
{
    ui->setupUi(this);
    MW1 * gameWindow = new MW1;
    Button * startButton = new Button(this->_startButton);
    startButton->setParent(this);
    startButton->move(600,300);
    connect(startButton, &Button::clicked, this, [=](){
        this->close();
        gameWindow->show();
    });
    Button * quitButton = new Button(this->_quitButton);
    quitButton->setParent(this);
    quitButton->move(600,350);
    connect(quitButton, &Button::clicked, this, &QApplication::quit);
}

SW::~SW()
{
    delete ui;
}

void SW::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.drawPixmap(0, 0, this->width(), this->height(), _backGround);
}
