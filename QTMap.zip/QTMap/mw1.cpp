#include "mw1.h"
#include "ui_mw1.h"
#include "icon.h"
#include <QTime>
#include <QTimer>
#include <map>
#include <iostream>
#include "button.h"

using namespace std;

MW1::MW1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW1)
{
    ui->setupUi(this);

    //init game world
    _game.initWorld("");//TODO Ӧ����������Ч�ĵ�ͼ�ļ�
    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl("qrc:/sounds/listen to the wind.mp3"));
    player->setVolume(20);
    player->play();

    timer1 = new QTimer(this);
    connect(timer1,SIGNAL(timeout()),this,SLOT(monsterMove()));
    connect(timer1,SIGNAL(timeout()),this,SLOT(updateMap()));

        //randomMove()Ϊ�Զ���ۺ���
    timer1->start(50);
    timer1->setInterval(100);

    timer2=new QTimer(this);
    connect(timer2,SIGNAL(timeout()),this,SLOT(loadWave()));
    timer2->start(50);
    timer2->setInterval(12000);

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));//�����������

    Button * tower=new Button(QPixmap(":/pics/tower.png"));
    tower->setParent(this);
    tower->move(10,30);
    connect(tower,&Button::clicked,this,&MW1::towerClicked);
    Button * tower0=new Button(QPixmap(":/pics/tower0.png"));
    tower0->setParent(this);
    tower0->move(80,30);
    connect(tower0,&Button::clicked,this,&MW1::tower0Clicked);
    Button * quitButton = new Button(QPixmap(":/pics/quit.png"));
    quitButton->setParent(this);
    quitButton->move(650,550);
    connect(quitButton, &Button::clicked, this, &QApplication::quit);
}

MW1::~MW1()
{
    delete ui;
}

void MW1::paintEvent(QPaintEvent *e){
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    pa->drawPixmap(0,0,width(),height(),QPixmap("../QTMap/background.png"));
    pa->setPen(Qt::red);
    pa->drawText(QRect(30,5,100,25),QString("HP : %1").arg(_game._HP));
    pa->drawText(QRect(350,5,100,25),QString("GOLD : %1").arg(_game._gold));
    pa->drawText(QRect(670,5,100,25),QString("WAVE : %1").arg(_waves));
    this->_game.show(pa);
    pa->end();
    delete pa;
    if(_game.lose||_game.win)
    {
        timer1->stop();
        timer2->stop();
        QPainter *p;
        p = new QPainter();
        p->begin(this);
        if(_game.win)
        {
            p->drawPixmap(0,0,width(),height(),QPixmap("../QTMap/win.png"));
        }else{
            p->drawPixmap(0,0,width(),height(),QPixmap("../QTMap/lose.png"));
        }
        return;
    }
}

void MW1::updateMap(){
    int n1=World::_towers.size();
    for(int i=0;i<n1;i++)
        World::_towers[i]->checkMonsterIn();
    int n2=World::_tower0.size();
    for(int i=0;i<n2;i++)
        World::_tower0[i]->checkMonsterIn();
    this->repaint();
    this->update();
}

/*void MW1::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for ��������
    if(e->key() == Qt::Key_A)
    {
        this->_game.handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->_game.handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->_game.handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->_game.handlePlayerMove(2,1);
    }
    this->repaint();
}*/

void MW1::mousePressEvent(QMouseEvent *e)
{
    QPoint pressPos = e->pos();
    vector<TowerPos*>::iterator it;
    it=this->_game._towerpos.begin();
    while (it!=this->_game._towerpos.end()) {
        bool flag1=(*it)->inArea(pressPos);
        bool flag2=(*it)->canPutTower();
        bool flag3=canBuyTower();
        bool flag4=canBuyTower0();
        if(flag1&&flag2&&flag3&&tower){
            _game._gold-=_game.towerCost;
            (*it)->setPutTower(false);
            Tower *t =new Tower((*it)->getPos());
            this->_game.addtower(t);
            break;
        }else if(flag1&&flag2&&flag4&&tower0){
            _game._gold-=_game.tower0Cost;
            (*it)->setPutTower(false);
            Tower0 *t =new Tower0((*it)->getPos());
            this->_game.addtower0(t);
            break;
        }/*else if(flag1&&(!flag2)){
            (*it)->setPutTower(true);
            vector<Tower*>::iterator t;
            t=World::_towers.begin();
            while (t!=World::_towers.end()) {
                if((*it)->getPos()==(*t)->getPos())
                {
                    delete (*t);
                    World::_towers.erase(t);
                    break;
                }
                t++;
            }
        }*/
        else{
            it++;
        }
    }
    this->update();
}

bool MW1::canBuyTower() const
{
    if(_game._gold>=_game.towerCost)
        return true;
    return false;
}

bool MW1::canBuyTower0() const
{
    if(_game._gold>=_game.tower0Cost)
        return true;
    return false;
}

void MW1::loadWave()
{
    if(_waves<6)
    {
        _waves++;
        int interval[]={1000,2000,3000,4000,5000};
        for(int i=0;i<5;i++)
        {
            QTimer *timer = new QTimer(this);
            connect(timer,SIGNAL(timeout()),this,SLOT(drawMonster()));
            timer->start(50);
            timer->setInterval(interval[i]);
            timer->setSingleShot(true);
        }
        int interval1[]={6000,7000,8000,9000,10000};
        for(int i=0;i<_waves-1;i++)
        {
            QTimer *timer = new QTimer(this);
            connect(timer,SIGNAL(timeout()),this,SLOT(drawBoss()));
            timer->start(50);
            timer->setInterval(interval1[i]);
            timer->setSingleShot(true);
        }
    }else{
        if(World::_monster.empty())
            _game.win=true;
    }
}

void MW1::monsterMove(){
    this->_game.MonsterMove();
}

void MW1::towerClicked()
{
    if(!tower)
        tower=true;
    else
        tower=false;
}

void MW1::tower0Clicked()
{
    if(!tower0)
        tower0=true;
    else
        tower0=false;
}
