#include "tower0.h"
#include "world.h"
#include <math.h>

Tower0::Tower0(QPoint p):_pos(p),_pixmap(":/pics/tower0.png")
{
    _rateTimer=new QTimer(this);
    connect(_rateTimer,SIGNAL(timeout()),this,SLOT(weapon()));
    _world=new World;
}
Tower0::~Tower0()
{
    delete _world;
}
void Tower0::show(QPainter * pa){
    pa->drawPixmap(_pos*5,_pixmap);
    pa->save();
    if(_chooseMonster)
    {
        QColor purple("#9932CC");
        QPen pen(purple);
        pen.setWidth(5);
        pen.setCapStyle(Qt::RoundCap);
        pen.setStyle(Qt::SolidLine);
        pa->setPen(pen);
        QPoint p1(this->_pos.x()*5+25,this->_pos.y()*5+25);
        QPoint p2(_chooseMonster->getPosX()*5+25,_chooseMonster->getPosY()*5+25);
        pa->drawLine(p1,p2);
        pa->setPen(Qt::red);
    }
    else
        pa->setPen(Qt::white);
    QPoint p(this->_pos.x()*5+25,this->_pos.y()*5+25);
    pa->drawEllipse(p,_attackRange,_attackRange);
    pa->restore();
}
bool Tower0::meet(QPoint p1, int r1, QPoint p2, int r2)
{
    double dx=p1.x()-p2.x();
    double dy=p1.y()-p2.y();
    double d=sqrt(dx*dx+dy*dy);
    if(d<=r1+r2)
        return true;
    else
        return false;
}
void Tower0::checkMonsterIn()
{
    if(this->_chooseMonster)
    {
        if(!meet(this->getPos(),_attackRange/5,this->_chooseMonster->getPos(),6))
            loseTarget();
    }else{
        int n=World::_monster.size();
        for(int i=0;i<n;i++)
        {
            if(meet(this->getPos(),_attackRange/5,World::_monster[i]->getPos(),6))
            {
                chooseMonster(World::_monster[i]);
                break;
            }
        }
    }
}
void Tower0::attackMonster(){
    this->_rateTimer->start(this->_rate);
}
void Tower0::chooseMonster(Monster *m){
    this->_chooseMonster=m;
    attackMonster();
    this->_chooseMonster->getAttacked(this);
}
void Tower0::weapon()
{
    vector<Monster*>::iterator it;
    it=find(World::_monster.begin(),World::_monster.end(),_chooseMonster);
    if (it!=World::_monster.end())
    {
        if((*it)->getObjType()=="monster")
            _world->monsterDamaged(*it,_damage);
        else
            _world->monsterDamaged(*it,_damage/4);
    }
}
void Tower0::targetKilled()
{
    if(this->_chooseMonster)
        this->_chooseMonster=NULL;
    _rateTimer->stop();
}
void Tower0::loseTarget()
{
    this->_chooseMonster->lostSight(this);
    if(this->_chooseMonster)
        this->_chooseMonster=NULL;
    _rateTimer->stop();
}
