#ifndef SW_H
#define SW_H

#include <QMainWindow>
#include <QPaintEvent>
#include <QPixmap>
#include <QPushButton>
#include <QPainter>
#include <QApplication>
#include "button.h"

namespace Ui{
class SW;
}

class SW : public QMainWindow
{
    Q_OBJECT

public:
    explicit SW(QWidget *parent = nullptr);
    ~SW();
    void paintEvent(QPaintEvent *e);

private:
    Ui::SW *ui;
    QPixmap _backGround;
    QPixmap _startButton;
    QPixmap _quitButton;
};

#endif // SW_H
