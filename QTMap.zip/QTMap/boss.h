#ifndef BOSS_H
#define BOSS_H
#include <QObject>
#include <QImage>
#include <QPainter>
#include <iostream>
#include <monster.h>

using namespace std;

class Tower;

class Boss:public Monster
{
public:
    Boss(){}
    ~Boss(){}
    bool operator ==(const Boss &b){return (this->_pos==b._pos);}
};

#endif // BOSS_H
