#ifndef END_H
#define END_H
#include "rpgobj.h"
#include <QMediaPlayer>

class End : public RPGObj
{
public:
    End();
    ~End();
};

#endif // END_H
