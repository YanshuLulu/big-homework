#include "mw1.h"
#include "sw.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    SW s;
    s.show();

    return a.exec();
}
